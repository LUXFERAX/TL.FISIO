import { useEffect, useRef, useState } from 'react';
import {
  MessageCircle,
  Facebook,
  Instagram,
  Mail,
  MapPin,
  Clock,
  Phone,
  BookOpen,
  ChevronDown,
  Heart,
  Zap,
  Shield,
} from 'lucide-react';

const WHATSAPP_NUMBER_1 = '5565998171995';
const WHATSAPP_NUMBER_2 = '5565998171995';
const FACEBOOK_URL = 'https://facebook.com';
const INSTAGRAM_URL = 'https://instagram.com/tlfisioterapia';
const EMAIL = 'tlfisioterapia@gmail.com';
const CURSO_URL =
  'https://pay.kiwify.com.br/6loaeGQ?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQMMjU2MjgxMDQwNTU4AAGnSRZNtbwvlYTuoyVGYxWD4yM3XzowrGoXNOX88e2XYPsBM1qO2uDufJdIqcY_aem_ZvhpO6IkJ7-JseNN5AaSyw&utm_id=97760_v0_s00_e0_tv3_a1denn';

function useIntersection(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

interface ContactButtonProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  sublabel?: string;
  colorClass: string;
  delay?: number;
}

function ContactButton({ href, icon, label, sublabel, colorClass, delay = 0 }: ContactButtonProps) {
  const { ref, visible } = useIntersection();
  return (
    <div
      ref={ref}
      style={{
        transitionDelay: `${delay}ms`,
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(24px)',
        transition: 'opacity 0.6s ease, transform 0.6s ease',
      }}
    >
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={`group flex items-center gap-4 w-full px-6 py-4 rounded-2xl font-semibold text-white shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95 ${colorClass}`}
      >
        <span className="text-2xl group-hover:rotate-12 transition-transform duration-300 flex-shrink-0">
          {icon}
        </span>
        <span className="flex flex-col leading-tight">
          <span className="text-base">{label}</span>
          {sublabel && <span className="text-xs font-normal opacity-80">{sublabel}</span>}
        </span>
      </a>
    </div>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  desc: string;
  delay?: number;
}

function FeatureCard({ icon, title, desc, delay = 0 }: FeatureCardProps) {
  const { ref, visible } = useIntersection();
  return (
    <div
      ref={ref}
      style={{
        transitionDelay: `${delay}ms`,
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(32px)',
        transition: 'opacity 0.7s ease, transform 0.7s ease',
      }}
      className="bg-[#1a1a2e]/60 border border-[#a3e635]/20 backdrop-blur-sm rounded-2xl p-6 flex flex-col items-center text-center gap-3 hover:border-[#a3e635]/50 hover:bg-[#1a1a2e]/80 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="w-14 h-14 rounded-xl bg-[#a3e635]/15 flex items-center justify-center text-[#a3e635]">
        {icon}
      </div>
      <h3 className="font-bold text-white text-lg">{title}</h3>
      <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
    </div>
  );
}

export default function App() {
  const { ref: heroRef, visible: heroVisible } = useIntersection(0.05);
  const { ref: infoRef, visible: infoVisible } = useIntersection();

  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <div className="min-h-screen bg-[#0f0f1a] text-white font-sans">
      {/* Sticky Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'bg-[#0f0f1a]/95 backdrop-blur-md shadow-lg shadow-black/30' : 'bg-transparent'
        }`}
      >
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <img
            src="/image.png"
            alt="TL Fisioterapia e Pilates"
            className="h-10 w-auto object-contain"
          />
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER_1}?text=Ola%2C%20gostaria%20de%20agendar%20uma%20consulta!`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-2 bg-[#a3e635] text-[#0f0f1a] text-sm font-bold px-4 py-2 rounded-full hover:bg-[#bef264] transition-colors duration-200"
          >
            <MessageCircle size={16} />
            Agendar Consulta
          </a>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 pt-24 pb-16 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-[#a3e635]/5 blur-3xl" />
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-[#7e22ce]/10 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full bg-[#a3e635]/8 blur-3xl" />
          <div className="absolute top-1/2 left-0 w-48 h-48 rounded-full bg-[#a3e635]/5 blur-2xl" />
        </div>

        <div
          ref={heroRef}
          style={{
            opacity: heroVisible ? 1 : 0,
            transform: heroVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'opacity 0.9s ease, transform 0.9s ease',
          }}
          className="relative flex flex-col items-center text-center max-w-2xl mx-auto gap-6"
        >
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-[#a3e635]/20 blur-2xl scale-110" />
            <img
              src="/image.png"
              alt="TL Fisioterapia e Pilates"
              className="relative w-48 h-48 sm:w-60 sm:h-60 object-contain drop-shadow-2xl"
            />
          </div>

          <div className="space-y-1">
            <p className="text-[#a3e635] text-sm font-semibold tracking-widest uppercase">
              Bem-vindo a
            </p>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">
              T.L. Fisioterapia
              <br />
              <span className="text-[#a3e635]">&amp; Pilates</span>
            </h1>
          </div>

          <p className="text-gray-300 text-base sm:text-lg leading-relaxed max-w-xl">
            Especialistas em fisioterapia, reabilitacao e pilates clinico em Cuiaba-MT.
            Com atendimento personalizado e humanizado, nossa equipe dedica-se a promover
            sua saude, movimento e qualidade de vida — do tratamento de lesoes ao
            condicionamento fisico, sempre com tecnica, cuidado e compromisso com seus
            resultados.
          </p>

          <div className="flex flex-wrap gap-3 justify-center">
            <span className="flex items-center gap-1.5 text-xs bg-[#a3e635]/15 text-[#a3e635] border border-[#a3e635]/30 px-3 py-1.5 rounded-full font-medium">
              <Heart size={12} /> Atendimento Humanizado
            </span>
            <span className="flex items-center gap-1.5 text-xs bg-[#a3e635]/15 text-[#a3e635] border border-[#a3e635]/30 px-3 py-1.5 rounded-full font-medium">
              <Zap size={12} /> Pilates Clinico
            </span>
            <span className="flex items-center gap-1.5 text-xs bg-[#a3e635]/15 text-[#a3e635] border border-[#a3e635]/30 px-3 py-1.5 rounded-full font-medium">
              <Shield size={12} /> Reabilitacao Especializada
            </span>
          </div>

          <a
            href="#contato"
            className="mt-2 flex flex-col items-center gap-1 text-gray-500 hover:text-[#a3e635] transition-colors animate-bounce"
          >
            <span className="text-xs">Ver mais</span>
            <ChevronDown size={18} />
          </a>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">O que oferecemos</h2>
            <div className="mt-2 w-16 h-1 bg-[#a3e635] rounded-full mx-auto" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <FeatureCard
              icon={<Zap size={28} />}
              title="Fisioterapia Clinica"
              desc="Avaliacao e tratamento de lesoes musculoesqueleticas, pos-operatorio e dores cronicas com tecnicas modernas e individualizadas."
              delay={0}
            />
            <FeatureCard
              icon={<Heart size={28} />}
              title="Pilates Clinico"
              desc="Aulas de pilates com foco terapeutico para fortalecimento, postura, flexibilidade e bem-estar geral do seu corpo."
              delay={120}
            />
            <FeatureCard
              icon={<Shield size={28} />}
              title="Reabilitacao"
              desc="Programas completos de reabilitacao para recuperacao de cirurgias, acidentes e condicoes neurologicas e ortopedicas."
              delay={240}
            />
          </div>
        </div>
      </section>

      {/* Info + Contato */}
      <section id="contato" className="py-16 px-4" ref={infoRef}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              Informacoes &amp; Contato
            </h2>
            <div className="mt-2 w-16 h-1 bg-[#a3e635] rounded-full mx-auto" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Info cards */}
            <div
              style={{
                opacity: infoVisible ? 1 : 0,
                transform: infoVisible ? 'translateX(0)' : 'translateX(-32px)',
                transition: 'opacity 0.7s ease, transform 0.7s ease',
              }}
              className="space-y-4"
            >
              <div className="bg-[#1a1a2e]/60 border border-[#a3e635]/20 rounded-2xl p-5 flex gap-4 items-start hover:border-[#a3e635]/40 transition-colors">
                <div className="w-10 h-10 min-w-[40px] rounded-xl bg-[#a3e635]/15 flex items-center justify-center text-[#a3e635]">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="font-semibold text-white text-sm mb-0.5">Localizacao</p>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    Av. Joao Gomes Sobrinho, 98<br />
                    Lixeira — Cuiaba, MT
                  </p>
                </div>
              </div>

              <div className="bg-[#1a1a2e]/60 border border-[#a3e635]/20 rounded-2xl p-5 flex gap-4 items-start hover:border-[#a3e635]/40 transition-colors">
                <div className="w-10 h-10 min-w-[40px] rounded-xl bg-[#a3e635]/15 flex items-center justify-center text-[#a3e635]">
                  <Clock size={20} />
                </div>
                <div>
                  <p className="font-semibold text-white text-sm mb-1">Horario de Funcionamento</p>
                  <p className="text-gray-400 text-sm">Segunda a Quinta: 7h as 18h</p>
                  <p className="text-[#fbbf24] text-xs font-medium mt-2 bg-[#fbbf24]/10 border border-[#fbbf24]/30 px-2 py-1.5 rounded-lg inline-block">
                    Atendimento exclusivamente por horario agendado
                  </p>
                </div>
              </div>

              <div className="bg-[#1a1a2e]/60 border border-[#a3e635]/20 rounded-2xl p-5 flex gap-4 items-start hover:border-[#a3e635]/40 transition-colors">
                <div className="w-10 h-10 min-w-[40px] rounded-xl bg-[#a3e635]/15 flex items-center justify-center text-[#a3e635]">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="font-semibold text-white text-sm mb-0.5">Telefone / WhatsApp</p>
                  <p className="text-gray-400 text-sm">(65) 9 9817-1995</p>
                </div>
              </div>

              <div className="bg-[#1a1a2e]/60 border border-[#a3e635]/20 rounded-2xl p-5 flex gap-4 items-start hover:border-[#a3e635]/40 transition-colors">
                <div className="w-10 h-10 min-w-[40px] rounded-xl bg-[#a3e635]/15 flex items-center justify-center text-[#a3e635]">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="font-semibold text-white text-sm mb-0.5">E-mail</p>
                  <p className="text-gray-400 text-sm break-all">{EMAIL}</p>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div
              style={{
                opacity: infoVisible ? 1 : 0,
                transform: infoVisible ? 'translateX(0)' : 'translateX(32px)',
                transition: 'opacity 0.7s ease 0.1s, transform 0.7s ease 0.1s',
              }}
              className="space-y-3"
            >
              <p className="text-gray-400 text-sm font-medium mb-2">
                Fale conosco pelos nossos canais:
              </p>

              <ContactButton
                href={`https://wa.me/${WHATSAPP_NUMBER_1}?text=Ola%2C%20gostaria%20de%20agendar%20uma%20consulta!`}
                icon={<MessageCircle size={22} />}
                label="WhatsApp — Contato 1"
                sublabel="(65) 9 9817-1995"
                colorClass="bg-[#25D366] hover:bg-[#1ebe5d]"
                delay={0}
              />

              <ContactButton
                href={`https://wa.me/${WHATSAPP_NUMBER_2}?text=Ola%2C%20gostaria%20de%20agendar%20uma%20consulta!`}
                icon={<MessageCircle size={22} />}
                label="WhatsApp — Contato 2"
                sublabel="(65) 9 9817-1995"
                colorClass="bg-[#128C7E] hover:bg-[#0d7a6d]"
                delay={80}
              />

              <ContactButton
                href={INSTAGRAM_URL}
                icon={<Instagram size={22} />}
                label="Instagram"
                sublabel="@tlfisioterapia"
                colorClass="bg-gradient-to-r from-[#f58529] via-[#dd2a7b] to-[#8134af] hover:opacity-90"
                delay={160}
              />

              <ContactButton
                href={FACEBOOK_URL}
                icon={<Facebook size={22} />}
                label="Facebook"
                sublabel="TL Fisioterapia e Pilates"
                colorClass="bg-[#1877F2] hover:bg-[#0d65d9]"
                delay={240}
              />

              <ContactButton
                href={`mailto:${EMAIL}`}
                icon={<Mail size={22} />}
                label="E-mail"
                sublabel={EMAIL}
                colorClass="bg-[#334155] hover:bg-[#475569]"
                delay={320}
              />

              <ContactButton
                href={CURSO_URL}
                icon={<BookOpen size={22} />}
                label="Curso / Apostila"
                sublabel="Adquira agora — acesso imediato"
                colorClass="bg-[#a3e635] !text-[#0f0f1a] hover:bg-[#bef264]"
                delay={400}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="py-10 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="rounded-2xl overflow-hidden border border-[#a3e635]/20 shadow-xl">
            <iframe
              title="Localizacao TL Fisioterapia"
              src="https://maps.google.com/maps?q=Av.+Jo%C3%A3o+Gomes+Sobrinho,+98,+Lixeira,+Cuiab%C3%A1,+MT&output=embed"
              width="100%"
              height="320"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <p className="text-center text-gray-500 text-xs mt-3">
            Av. Joao Gomes Sobrinho, 98 — Lixeira, Cuiaba-MT
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-[#a3e635]/10 mt-4">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-gray-500 text-xs">
          <div className="flex items-center gap-3">
            <img
              src="/image.png"
              alt="TL Fisioterapia"
              className="h-8 w-auto object-contain opacity-70"
            />
            <span>TL Fisioterapia e Pilates — Cuiaba, MT</span>
          </div>
          <span>&copy; {new Date().getFullYear()} Todos os direitos reservados</span>
        </div>
      </footer>

      {/* Floating WhatsApp button */}
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER_1}?text=Ola%2C%20gostaria%20de%20agendar%20uma%20consulta!`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-2xl hover:scale-110 active:scale-95 transition-transform duration-200"
        aria-label="WhatsApp"
      >
        <MessageCircle size={26} className="text-white" />
      </a>
    </div>
  );
}
